﻿#include "stdio.h"
#include "stdlib.h"

int main(void)
{
	printf("\n参考情報源：");
	printf("\nhttp://hakuda2.web.fc2.com/wario/poke1/mo.html");
	printf("\n↑「◆内部コード表◆」欄から各項目へジャンプ");
	printf("\nhttp://www.geocities.jp/kattempla/pokebug/mojicodep.html");
	printf("\nhttp://www.geocities.jp/kattempla/pokebug/mojicodem.html");
	printf("\nhttp://www.geocities.jp/kattempla/pokebug/pokename.html");
	printf("\nhttp://www.geocities.jp/kattempla/pokebug/itemcode2.html");
	printf("\nhttp://njprog.com/z80_004.htm\nhttp://njprog.com/z80_005.htm\nhttp://njprog.com/z80_006.htm");
	printf("\nhttp://www.pastraiser.com/cpu/gameboy/gameboy_opcodes.html");
	printf("\nこれらのサイトに掲載されている情報を参照しながら作成。\n");
    printf("\n動作検証に利用したサイト（トップページ）一覧：\nhttp://www.geocities.jp/kattempla/pokebug/index.html\nhttp://www.msmrrenda.net/~renda/select/\n\n");
    
    return 0;
}